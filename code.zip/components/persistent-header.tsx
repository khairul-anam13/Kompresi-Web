'use client'

import { useState, useEffect } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { Volume2, VolumeX, ArrowLeft, Maximize2, Minimize2 } from 'lucide-react'

interface PersistentHeaderProps {
  showBackButton?: boolean
  backHref?: string
  showLogo?: boolean
}

export function PersistentHeader({ 
  showBackButton = true, 
  backHref,
  showLogo = false 
}: PersistentHeaderProps) {
  const router = useRouter()
  const pathname = usePathname()
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [isMusicOn, setIsMusicOn] = useState(true)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen()
        setIsFullscreen(true)
      } else {
        await document.exitFullscreen()
        setIsFullscreen(false)
      }
    } catch (error) {
      console.error('Fullscreen error:', error)
    }
  }

  const handleBackClick = () => {
    if (backHref) {
      router.push(backHref)
    } else {
      router.back()
    }
  }

  // Jangan tampilkan header di splash screen
  const isSplashScreen = pathname === '/'
  if (isSplashScreen) return null

  if (!mounted) return null

  return (
    <div className="fixed top-0 left-0 right-0 flex items-center justify-between px-4 py-4 z-50 pointer-events-none">
      {/* Left Controls - Enhanced Liquid Glass Buttons */}
      <div className="flex gap-3 pointer-events-auto">
        <button
          onClick={handleFullscreen}
          className="glass-button"
          aria-label="Toggle fullscreen"
        >
          {isFullscreen ? (
            <Minimize2 className="w-5 h-5" />
          ) : (
            <Maximize2 className="w-5 h-5" />
          )}
        </button>
        <button
          onClick={() => setIsMusicOn(!isMusicOn)}
          className="glass-button"
          aria-label="Toggle music"
        >
          {isMusicOn ? (
            <Volume2 className="w-5 h-5" />
          ) : (
            <VolumeX className="w-5 h-5" />
          )}
        </button>
      </div>

      {/* Right Controls - Logo or Back Button */}
      <div className="flex gap-3 pointer-events-auto">
        {showBackButton ? (
          <button
            onClick={handleBackClick}
            className="glass-button"
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        ) : null}
        
        {showLogo && (
          <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-ios-md flex items-center justify-center shadow-lg shadow-primary/20 backdrop-blur-md border border-white/30 hover:shadow-primary/40 transition-all duration-300">
            <span className="text-white text-lg font-bold">⚡</span>
          </div>
        )}
      </div>
    </div>
  )
}

'use client'

import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { PerspectiveCamera } from '@react-three/drei'
import { Suspense, useRef, useEffect, useState } from 'react'
import * as THREE from 'three'

function EarthMesh() {
  const earthRef = useRef<THREE.Mesh>(null)
  const cloudsRef = useRef<THREE.Mesh>(null)
  
  const textureLoader = new THREE.TextureLoader()

  // Load textures
  const earthTexture = textureLoader.load('https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/textures/planets/earth_atmos_2048.jpg')
  const earthBump = textureLoader.load('https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/textures/planets/earth_normal_2048.jpg')
  const earthSpec = textureLoader.load('https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/textures/planets/earth_specular_2048.jpg')
  const cloudsTexture = textureLoader.load('https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/textures/planets/earth_clouds_1024.png')

  useFrame(() => {
    if (earthRef.current) {
      earthRef.current.rotation.y += 0.001
    }
    if (cloudsRef.current) {
      cloudsRef.current.rotation.y += 0.0015
    }
  })

  return (
    <>
      {/* Earth */}
      <mesh ref={earthRef}>
        <sphereGeometry args={[1.2, 32, 32]} />
        <meshPhongMaterial
          map={earthTexture}
          bumpMap={earthBump}
          bumpScale={0.03}
          specularMap={earthSpec}
          shininess={20}
        />
      </mesh>

      {/* Clouds */}
      <mesh ref={cloudsRef}>
        <sphereGeometry args={[1.22, 32, 32]} />
        <meshPhongMaterial
          map={cloudsTexture}
          transparent
          opacity={0.3}
          depthWrite={false}
        />
      </mesh>

      {/* Adaptive Lighting */}
      <ambientLight intensity={0.4} />
      <pointLight position={[3, 2, 3]} intensity={0.8} />
      <pointLight position={[-3, -1, -2]} intensity={0.3} color={0x0099ff} />
    </>
  )
}

function ResponsiveCamera() {
  const { size, camera } = useThree()
  const cameraRef = useRef<THREE.PerspectiveCamera>(null)

  useEffect(() => {
    if (cameraRef.current) {
      const aspect = size.width / size.height
      
      // Dynamic camera distance based on aspect ratio
      let distance = 3.5
      let fov = 45
      
      if (aspect > 2) {
        // Very wide screens
        distance = 4.0
        fov = 35
      } else if (aspect > 1.5) {
        // Wide screens
        distance = 3.8
        fov = 40
      } else if (aspect < 0.7) {
        // Very tall screens
        distance = 3.0
        fov = 50
      } else if (aspect < 1) {
        // Tall screens
        distance = 3.2
        fov = 48
      }
      
      cameraRef.current.position.z = distance
      cameraRef.current.fov = fov
      cameraRef.current.updateProjectionMatrix()
    }
  }, [size, camera])

  return (
    <PerspectiveCamera
      ref={cameraRef}
      makeDefault
      fov={45}
      aspect={size.width / size.height}
      near={0.1}
      far={100}
    />
  )
}

function AdaptiveScene() {
  return (
    <>
      <ResponsiveCamera />
      <EarthMesh />
    </>
  )
}

export function Earth3D() {
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  if (!isMounted) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-transparent">
        <div className="text-center">
          <div className="w-12 h-12 border-3 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-foreground/60 text-sm">Memuat Bumi 3D...</p>
        </div>
      </div>
    )
  }

  return (
    <div 
      className="w-full h-full relative flex items-center justify-center bg-transparent"
      style={{ 
        aspectRatio: '1 / 1'
      }}
    >
      <Canvas
        className="w-full h-full bg-transparent"
        gl={{ 
          antialias: true, 
          alpha: true,
          powerPreference: "high-performance",
          // Pastikan alpha channel aktif
          preserveDrawingBuffer: false,
          depth: true,
          stencil: false
        }}
        dpr={Math.min(window.devicePixelRatio, 1.5)}
        style={{
          display: 'block',
          width: '100%',
          height: '100%',
          background: 'transparent', // Pastikan style background transparan
          backgroundColor: 'transparent' // Double insurance
        }}
        // Important: Set scene background to transparent
        onCreated={({ gl }) => {
          gl.setClearAlpha(0) // Set alpha clear value to 0 (transparent)
        }}
      >
        {/* Hapus color background dari scene */}
        <Suspense fallback={null}>
          <AdaptiveScene />
        </Suspense>
      </Canvas>
    </div>
  )
}

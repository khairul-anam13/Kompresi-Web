'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { useEffect, useState } from 'react'
import { Volume2, VolumeX, Maximize2 } from 'lucide-react'
import { Earth3D } from '@/components/earth-3d'

export default function SplashScreen() {
  const [isMusicOn, setIsMusicOn] = useState(true)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen()
        setIsFullscreen(true)
      } else {
        await document.exitFullscreen()
        setIsFullscreen(false)
      }
    } catch (error) {
      console.error('Fullscreen error:', error)
    }
  }

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-background to-green-50 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl pointer-events-none animate-pulse"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl pointer-events-none animate-pulse" style={{ animationDelay: '1s' }}></div>
      
      <div className="min-h-screen flex flex-col lg:flex-row items-stretch relative z-10">
        {/* Mobile & Tablet: Earth on Top */}
        <div className="flex lg:hidden w-full items-center justify-center p-4 bg-transparent">
          <div className="w-full max-w-[280px] h-[280px] sm:max-w-[320px] sm:h-[320px] flex items-center justify-center">
            <Earth3D />
          </div>
        </div>

        {/* Desktop: Earth on Left Side */}
        <div className="hidden lg:flex lg:w-1/2 items-center justify-center p-8 bg-transparent">
          <div className="w-full max-w-[400px] h-[400px] xl:max-w-[480px] xl:h-[480px] flex items-center justify-center">
            <Earth3D />
          </div>
        </div>

        {/* Right Side - Content Area */}
        <div className="w-full lg:w-1/2 flex flex-col justify-between p-4 sm:p-6 md:p-8 lg:p-12 relative">
          {/* Top Controls */}
          <div className="flex justify-between items-start gap-4 mb-4 lg:mb-0">
            <div className="flex gap-2 sm:gap-3">
              <button 
                onClick={handleFullscreen}
                className="glass-button p-2 sm:p-3"
                aria-label="Fullscreen"
              >
                <Maximize2 className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
              <button 
                onClick={() => setIsMusicOn(!isMusicOn)}
                className="glass-button p-2 sm:p-3"
                aria-label="Toggle music"
              >
                {isMusicOn ? (
                  <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" />
                ) : (
                  <VolumeX className="w-4 h-4 sm:w-5 sm:h-5" />
                )}
              </button>
            </div>

          </div>

          {/* Center - Title */}
          <div className="flex-1 flex items-center py-4 lg:py-0">
            <div className="space-y-4 sm:space-y-6">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-display font-bold text-foreground leading-tight text-balance">
                Laboratorium <br />
                <span className="text-gradient">Virtual Energi</span> <br />
                Terbarukan
              </h1>
              <p className="text-base sm:text-lg text-muted-foreground max-w-md sm:max-w-lg font-sans leading-relaxed">
                Jelajahi dan pelajari berbagai sumber energi terbarukan melalui simulasi interaktif dan virtual lab yang menarik.
              </p>
            </div>
          </div>

          {/* Bottom - Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 pt-6 lg:pt-8">
            <Link href="/menu" className="flex-1">
              <Button className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground h-12 sm:h-14 text-base sm:text-lg rounded-ios-md font-semibold shadow-lg hover:shadow-xl transition-all active:scale-95">
                Mulai
              </Button>
            </Link>
            <Button 
              variant="outline" 
              className="flex-1 h-12 sm:h-14 text-base sm:text-lg rounded-ios-md font-semibold border-2 border-secondary hover:bg-secondary/10 transition-all active:scale-95"
              onClick={() => {
                if (typeof window !== 'undefined') window.close()
              }}
            >
              Keluar
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default function Profil() {
  const team = [
    {
      name: 'Dr. Bambang Sutrisno',
      role: 'Ketua Pengembang',
      expertise: 'Energi Terbarukan & Sustainability'
    },
    {
      name: 'Ir. Siti Nurhaliza',
      role: 'Developer & Scientist',
      expertise: 'Sistem Fotovoltaik & Solar Energy'
    },
    {
      name: 'Rudi Hermanto, S.Kom',
      role: 'Lead Developer',
      expertise: 'Web Development & UI/UX'
    },
    {
      name: 'Maya Wijaya, S.Pd',
      role: 'Instructional Designer',
      expertise: 'Kurikulum & Learning Experience'
    }
  ]

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2">
              Tentang <span className="text-primary">Kami</span>
            </h1>
            <p className="text-muted-foreground">Berkenalan dengan tim di balik Energy Explorer</p>
          </div>
          <Link href="/menu">
            <Button variant="outline" size="sm">← Kembali</Button>
          </Link>
        </div>

        {/* About Section */}
        <div className="bg-primary/10 border-2 border-primary rounded-xl p-8 mb-12">
          <h2 className="text-2xl font-bold text-foreground mb-4">Misi Kami</h2>
          <p className="text-muted-foreground leading-relaxed mb-4">
            Energy Explorer dikembangkan dengan tujuan untuk mengedukasi generasi muda tentang pentingnya energi terbarukan dan berkelanjutan. Platform ini menyediakan pengalaman pembelajaran interaktif yang menggabungkan teori dan praktik melalui virtual lab.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            Kami percaya bahwa pendidikan berkualitas tentang energi terbarukan adalah kunci untuk masa depan yang lebih hijau dan berkelanjutan.
          </p>
        </div>

        {/* Team Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-foreground mb-8">Tim Pengembang</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {team.map((member, idx) => (
              <div key={idx} className="bg-card border border-border rounded-lg p-6">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-full mb-4 flex items-center justify-center text-white font-bold">
                  {member.name.split(' ')[0][0]}
                </div>
                <h3 className="text-lg font-bold text-foreground">{member.name}</h3>
                <p className="text-sm font-semibold text-primary mb-2">{member.role}</p>
                <p className="text-sm text-muted-foreground">{member.expertise}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Info Section */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bg-secondary/10 border border-secondary rounded-lg p-6 text-center">
            <p className="text-3xl font-bold text-secondary mb-2">4</p>
            <p className="text-sm font-medium text-foreground">Topik Pembelajaran</p>
          </div>
          <div className="bg-accent/10 border border-accent rounded-lg p-6 text-center">
            <p className="text-3xl font-bold text-accent mb-2">3</p>
            <p className="text-sm font-medium text-foreground">Simulasi Virtual Lab</p>
          </div>
          <div className="bg-primary/10 border border-primary rounded-lg p-6 text-center">
            <p className="text-3xl font-bold text-primary mb-2">∞</p>
            <p className="text-sm font-medium text-foreground">Peluang Belajar</p>
          </div>
        </div>

        {/* Contact Section */}
        <div className="bg-card border border-border rounded-lg p-8">
          <h3 className="text-xl font-bold text-foreground mb-4">Hubungi Kami</h3>
          <p className="text-muted-foreground mb-2">
            Email: <span className="font-semibold text-foreground">info@energyexplorer.edu</span>
          </p>
          <p className="text-muted-foreground">
            Website: <span className="font-semibold text-foreground">www.energyexplorer.edu</span>
          </p>
        </div>

        {/* Footer Navigation */}
        <div className="mt-8">
          <Link href="/menu">
            <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
              Kembali ke Menu Utama
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

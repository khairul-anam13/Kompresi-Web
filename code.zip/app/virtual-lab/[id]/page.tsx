'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ChevronLeft } from 'lucide-react'

interface PageProps {
  params: Promise<{ id: string }>
}

export default function VirtualLabSimulation({ params }: PageProps) {
  const { id } = (params as any)
  const [stage, setStage] = useState<'assembly' | 'simulation'>('assembly')
  const [components, setComponents] = useState({
    mounted: false,
    connected: false,
    calibrated: false
  })

  const labConfigs = {
    'panel-surya': {
      title: 'Simulasi Panel Surya',
      components: ['Frame', 'Sel Surya', 'Glass Cover', 'Junction Box', 'Kabel'],
      variables: ['Intensitas Cahaya (%)', 'Suhu (°C)', 'Sudut Kemiringan (°)']
    },
    'turbin-air': {
      title: 'Simulasi Turbin Air',
      components: ['Inlet', 'Rotor', 'Generator', 'Outlet', 'Kontrol Debit'],
      variables: ['Debit Air (L/s)', 'Ketinggian Jatuh (m)', 'RPM Turbin']
    },
    'turbin-angin': {
      title: 'Simulasi Turbin Angin',
      components: ['Blade', 'Hub', 'Generator', 'Tower', 'Kontrol Pitch'],
      variables: ['Kecepatan Angin (m/s)', 'Sudut Pitch (°)', 'RPM Rotor']
    }
  }

  const config = (labConfigs as any)[id] || labConfigs['panel-surya']

  const handleAssemblyComplete = () => {
    setComponents({ mounted: true, connected: true, calibrated: true })
    setStage('simulation')
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link href="/virtual-lab">
              <Button variant="outline" size="sm">← Kembali ke Virtual Lab</Button>
            </Link>
            <h1 className="text-3xl md:text-4xl font-bold font-display text-foreground text-stroke mt-3">{config.title}</h1>
          </div>
        </div>

        {/* Stage Indicator */}
        <div className="bg-card border border-border rounded-lg p-4 mb-8">
          <div className="flex gap-4">
            <button
              onClick={() => setStage('assembly')}
              className={`flex-1 py-2 px-4 rounded-lg font-semibold transition-all ${
                stage === 'assembly'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-border'
              }`}
            >
              ⚙️ Perakitan
            </button>
            <button
              onClick={() => setStage('simulation')}
              disabled={!components.calibrated}
              className={`flex-1 py-2 px-4 rounded-lg font-semibold transition-all ${
                stage === 'simulation'
                  ? 'bg-primary text-primary-foreground'
                  : components.calibrated
                  ? 'bg-muted text-muted-foreground hover:bg-border cursor-pointer'
                  : 'bg-muted text-muted-foreground opacity-50 cursor-not-allowed'
              }`}
            >
              ▶️ Simulasi
            </button>
          </div>
        </div>

        {/* Assembly Stage */}
        {stage === 'assembly' && (
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            {/* Component List */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-xl font-bold text-foreground mb-4">Komponen yang Diperlukan</h2>
              <div className="space-y-3">
                {config.components.map((component: string, idx: number) => (
                  <div
                    key={idx}
                    className="p-4 bg-primary/10 border border-primary rounded-lg hover:bg-primary/20 transition-colors cursor-grab"
                  >
                    <p className="font-medium text-foreground">{component}</p>
                    <p className="text-xs text-muted-foreground">Drag ke area perakitan</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Assembly Area */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-xl font-bold text-foreground mb-4">Area Perakitan</h2>
              <div className="h-64 border-2 border-dashed border-border rounded-lg flex items-center justify-center bg-background/50 mb-4">
                <div className="text-center">
                  <p className="text-muted-foreground mb-2">Drag komponen ke sini</p>
                  <p className="text-3xl">⬅️</p>
                </div>
              </div>
              {!components.calibrated ? (
                <Button
                  onClick={handleAssemblyComplete}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  ✓ Selesai Merakit
                </Button>
              ) : (
                <div className="text-center py-3 bg-green-100 rounded-lg">
                  <p className="text-green-700 font-semibold">✓ Perakitan Lengkap</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Simulation Stage */}
        {stage === 'simulation' && (
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            {/* Controls */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-xl font-bold text-foreground mb-4">Kontrol Simulasi</h2>
              <div className="space-y-5">
                {config.variables.map((variable: string, idx: number) => (
                  <div key={idx}>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      {variable}
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      defaultValue="50"
                      className="w-full h-2 bg-border rounded-lg appearance-none cursor-pointer accent-primary"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Nilai: 50%</p>
                  </div>
                ))}
              </div>
              <Button className="w-full mt-6 bg-primary hover:bg-primary/90 text-primary-foreground">
                Jalankan Simulasi
              </Button>
            </div>

            {/* Results */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-xl font-bold text-foreground mb-4">Hasil Simulasi</h2>
              <div className="space-y-4">
                <div className="bg-secondary/10 p-4 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-1">Output Daya</p>
                  <p className="text-3xl font-bold text-secondary">450 W</p>
                </div>
                <div className="bg-accent/10 p-4 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-1">Efisiensi</p>
                  <p className="text-3xl font-bold text-accent">18.5%</p>
                </div>
                <div className="bg-primary/10 p-4 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-1">Status</p>
                  <p className="text-lg font-semibold text-primary">✓ Operasional Normal</p>
                </div>
              </div>

              {/* Simple Chart */}
              <div className="mt-6">
                <p className="text-sm font-medium text-foreground mb-3">Grafik Performa</p>
                <div className="flex items-end justify-around h-32 bg-background rounded-lg p-4">
                  {[40, 70, 60, 85, 75, 90, 80].map((height, idx) => (
                    <div
                      key={idx}
                      className="w-full bg-gradient-to-t from-primary to-primary/50 rounded-t mx-1"
                      style={{ height: `${height}%` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

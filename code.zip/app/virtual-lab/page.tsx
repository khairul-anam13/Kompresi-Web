'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ChevronRight } from 'lucide-react'

export default function VirtualLabMenu() {
  const labs = [
    {
      id: 'panel-surya',
      title: 'Merakit Panel Surya',
      description: 'Simulasi merakit dan mengoperasikan panel surya',
      icon: '☀️',
      color: 'from-orange-400 to-red-500'
    },
    {
      id: 'turbin-air',
      title: 'Merakit Turbin Air',
      description: 'Simulasi konstruksi dan operasi turbin air',
      icon: '💧',
      color: 'from-blue-400 to-cyan-500'
    },
    {
      id: 'turbin-angin',
      title: 'Merakit Turbin Angin',
      description: 'Simulasi perakitan turbin angin yang efisien',
      icon: '💨',
      color: 'from-slate-400 to-blue-500'
    }
  ]

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2">
              <span className="text-secondary">Virtual</span> Lab
            </h1>
            <p className="text-muted-foreground">Simulasi interaktif energi terbarukan</p>
          </div>
          <Link href="/menu">
            <Button variant="outline" size="sm">← Kembali</Button>
          </Link>
        </div>

        {/* Labs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {labs.map((lab) => (
            <Link key={lab.id} href={`/virtual-lab/${lab.id}`}>
              <div className={`bg-gradient-to-br ${lab.color} rounded-2xl p-6 cursor-pointer transform transition-all hover:scale-105 hover:shadow-xl text-white group min-h-48 flex flex-col justify-between`}>
                <div className="flex items-start justify-between">
                  <span className="text-4xl">{lab.icon}</span>
                  <ChevronRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">{lab.title}</h3>
                  <p className="text-white/90 text-sm">{lab.description}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Info Section */}
        <div className="bg-secondary/10 border-2 border-secondary rounded-xl p-6">
          <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
            <span>💡</span> Bagaimana Cara Kerja Virtual Lab?
          </h3>
          <ol className="space-y-3 text-sm text-muted-foreground">
            <li className="flex gap-3">
              <span className="font-bold text-primary">1</span>
              <span>Pilih salah satu simulasi dari pilihan di atas</span>
            </li>
            <li className="flex gap-3">
              <span className="font-bold text-primary">2</span>
              <span>Ikuti instruksi untuk merakit komponen</span>
            </li>
            <li className="flex gap-3">
              <span className="font-bold text-primary">3</span>
              <span>Atur variabel dalam simulasi</span>
            </li>
            <li className="flex gap-3">
              <span className="font-bold text-primary">4</span>
              <span>Amati hasil dan analisis output</span>
            </li>
          </ol>
        </div>
      </div>
    </div>
  )
}

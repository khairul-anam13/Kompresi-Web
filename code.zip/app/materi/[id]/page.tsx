'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ChevronLeft, ChevronRight } from 'lucide-react'

const materiContent = {
  8: {
    title: 'Energi Listrik Terbarukan (EBT)',
    views: [
      {
        id: 'capaian',
        title: 'Capaian Pembelajaran',
        content: 'Setelah mempelajari materi ini, Anda diharapkan dapat:\n• Memahami konsep energi terbarukan\n• Menjelaskan manfaat energi terbarukan\n• Membedakan berbagai jenis energi terbarukan\n• Menganalisis potensi energi terbarukan di Indonesia'
      },
      {
        id: 'materi',
        title: 'Konten Materi',
        content: 'Energi Listrik Terbarukan (EBT) adalah energi yang berasal dari sumber alam yang dapat diperbaharui. Sumber-sumber ini antara lain matahari, angin, air, dan geothermal.\n\nKelebihan energi terbarukan:\n- Ramah lingkungan\n- Tidak terbatas\n- Mengurangi emisi karbon\n\nJenis-jenis energi terbarukan:\n1. Solar (Matahari)\n2. Wind (Angin)\n3. Hydro (Air)\n4. Geothermal (Panas Bumi)'
      },
      {
        id: 'video',
        title: 'Video Pembelajaran',
        content: '[Video akan dimuat di sini]\n\nTonton penjelasan lengkap tentang energi terbarukan dari para ahli. Video ini menjelaskan dasar-dasar EBT dan aplikasinya di industri modern.'
      },
      {
        id: 'referensi',
        title: 'Referensi & Sumber',
        content: '1. MEMR (Kementerian ESDM) - Roadmap Energi Terbarukan\n2. IEA - Renewable Energy Reports\n3. IRENA - International Renewable Energy Agency\n4. PLN - Program Pengembangan Energi Terbarukan\n\nWahana pembelajaran tambahan:\n- Laman resmi MEMR\n- Portal energi terbarukan Indonesia'
      }
    ]
  },
  9: {
    title: 'Panel Surya',
    views: [
      {
        id: 'capaian',
        title: 'Capaian Pembelajaran',
        content: 'Setelah mempelajari materi ini, Anda dapat:\n• Memahami cara kerja panel surya\n• Menjelaskan komponen-komponen panel surya\n• Menghitung efisiensi panel surya\n• Merancang instalasi panel surya sederhana'
      },
      {
        id: 'materi',
        title: 'Konten Materi',
        content: 'Panel Surya mengubah energi cahaya matahari menjadi energi listrik melalui efek fotovoltaik.\n\nKomponen utama:\n- Sel surya (Photovoltaic cells)\n- Frame aluminium\n- Kaca tempered\n- Backing sheet\n- Junction box\n\nProses konversi energi surya mengikuti prinsip quantum mechanics dan physical properties dari material semiconductor.'
      },
      {
        id: 'video',
        title: 'Video Pembelajaran',
        content: '[Video akan dimuat di sini]\n\nPenjelasan visual tentang cara kerja panel surya dan instalasi modern.'
      },
      {
        id: 'referensi',
        title: 'Referensi & Sumber',
        content: 'Standar dan dokumentasi:\n- IEC 61215 - Photovoltaic Module Quality Standard\n- Pedoman instalasi MEMR\n- Studi kasus panel surya di Indonesia'
      }
    ]
  },
  10: {
    title: 'Turbin Air',
    views: [
      {
        id: 'capaian',
        title: 'Capaian Pembelajaran',
        content: 'Tujuan pembelajaran materi turbin air'
      },
      {
        id: 'materi',
        title: 'Konten Materi',
        content: 'Materi tentang turbin air dan cara kerjanya'
      },
      {
        id: 'video',
        title: 'Video Pembelajaran',
        content: '[Video akan dimuat di sini]'
      },
      {
        id: 'referensi',
        title: 'Referensi & Sumber',
        content: 'Sumber-sumber terkait turbin air'
      }
    ]
  },
  11: {
    title: 'Turbin Angin',
    views: [
      {
        id: 'capaian',
        title: 'Capaian Pembelajaran',
        content: 'Tujuan pembelajaran materi turbin angin'
      },
      {
        id: 'materi',
        title: 'Konten Materi',
        content: 'Materi tentang turbin angin dan mekanisme kerjanya'
      },
      {
        id: 'video',
        title: 'Video Pembelajaran',
        content: '[Video akan dimuat di sini]'
      },
      {
        id: 'referensi',
        title: 'Referensi & Sumber',
        content: 'Sumber-sumber terkait turbin angin'
      }
    ]
  }
}

interface PageProps {
  params: Promise<{ id: string }>
}

export default function MateriDetail({ params }: PageProps) {
  const { id } = (params as any) // Accessing directly since awaiting params in client component is not typical
  const [currentViewIndex, setCurrentViewIndex] = useState(0)
  
  const content = (materiContent as any)[id]
  
  if (!content) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Materi tidak ditemukan</h1>
          <Link href="/materi">
            <Button>Kembali ke Daftar Materi</Button>
          </Link>
        </div>
      </div>
    )
  }

  const currentView = content.views[currentViewIndex]
  const hasNextView = currentViewIndex < content.views.length - 1
  const hasPrevView = currentViewIndex > 0

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link href="/materi">
              <Button variant="outline" size="sm">← Kembali ke Materi</Button>
            </Link>
            <h1 className="text-3xl md:text-4xl font-bold font-display text-foreground text-stroke mt-3">{content.title}</h1>
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="bg-card border border-border rounded-lg p-4 mb-8">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-sm font-semibold text-muted-foreground">
              {currentViewIndex + 1} dari {content.views.length}
            </span>
          </div>
          <div className="flex gap-2">
            {content.views.map((view: any, idx: number) => (
              <button
                key={idx}
                onClick={() => setCurrentViewIndex(idx)}
                className={`flex-1 h-2 rounded-full transition-all ${
                  idx === currentViewIndex
                    ? 'bg-primary'
                    : 'bg-border hover:bg-muted'
                }`}
                title={view.title}
              />
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-card border border-border rounded-lg p-6 md:p-8 mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-4">{currentView.title}</h2>
          <div className="text-muted-foreground whitespace-pre-wrap leading-relaxed">
            {currentView.content}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between gap-4">
          <Button
            variant="outline"
            onClick={() => setCurrentViewIndex(prev => Math.max(0, prev - 1))}
            disabled={!hasPrevView}
            className="flex-1"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Sebelumnya
          </Button>

          {hasNextView && (
            <Button
              className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
              onClick={() => setCurrentViewIndex(prev => Math.min(content.views.length - 1, prev + 1))}
            >
              Selanjutnya
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          )}
          
          {!hasNextView && (
            <Link href="/materi" className="flex-1">
              <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                Selesai - Kembali ke Materi
              </Button>
            </Link>
          )}
        </div>
      </div>
    </div>
  )
}

'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ChevronRight } from 'lucide-react'

export default function MateriMenu() {
  const topics = [
    {
      id: 8,
      title: 'Energi Listrik Terbarukan (EBT)',
      description: 'Pelajari konsep dasar energi listrik terbarukan',
      icon: '⚡',
      color: 'from-yellow-400 to-orange-500'
    },
    {
      id: 9,
      title: 'Panel Surya',
      description: 'Konversi energi matahari menjadi listrik',
      icon: '☀️',
      color: 'from-orange-400 to-red-500'
    },
    {
      id: 10,
      title: 'Turbin Air',
      description: 'Memanfaatkan energi aliran air',
      icon: '💧',
      color: 'from-blue-400 to-cyan-500'
    },
    {
      id: 11,
      title: 'Turbin Angin',
      description: 'Memanfaatkan energi angin untuk listrik',
      icon: '💨',
      color: 'from-slate-400 to-blue-500'
    }
  ]

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2">
              Materi <span className="text-primary">Pembelajaran</span>
            </h1>
            <p className="text-muted-foreground">Pilih topik energi terbarukan yang ingin dipelajari</p>
          </div>
          <Link href="/menu">
            <Button variant="outline" size="sm">← Kembali</Button>
          </Link>
        </div>

        {/* Topics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {topics.map((topic) => (
            <Link key={topic.id} href={`/materi/${topic.id}`}>
              <div className={`bg-gradient-to-br ${topic.color} rounded-2xl p-6 md:p-8 cursor-pointer transform transition-all hover:scale-105 hover:shadow-xl text-white group min-h-40 flex flex-col justify-between`}>
                <div className="flex items-start justify-between">
                  <span className="text-4xl">{topic.icon}</span>
                  <ChevronRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">{topic.title}</h3>
                  <p className="text-white/90 text-sm">{topic.description}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Quick Access Section */}
        <div className="bg-primary/10 border-2 border-primary rounded-xl p-6 mb-8">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <span>📝</span> Evaluasi
          </h3>
          <p className="text-muted-foreground mb-4">Setelah mempelajari semua materi, ikuti evaluasi untuk mengukur pemahaman Anda.</p>
          <Link href="/evaluasi">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Buka Evaluasi →
            </Button>
          </Link>
        </div>

        {/* Navigation Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Link href="/menu" className="flex-1">
            <Button variant="outline" className="w-full">Kembali ke Menu</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

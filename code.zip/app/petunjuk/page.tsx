'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ChevronDown, ChevronUp } from 'lucide-react'
import { useState } from 'react'

export default function Petunjuk() {
  const [openIndex, setOpenIndex] = useState(0)

  const guides = [
    {
      title: 'Mulai Belajar',
      content: 'Klik tombol "Mulai Belajar" di halaman awal untuk masuk ke menu utama. Dari sini Anda dapat memilih kategori pembelajaran yang ingin dipelajari.'
    },
    {
      title: 'Pilih Materi',
      content: 'Di bagian "Materi Pembelajaran", pilih salah satu topik energi terbarukan. Setiap topik memiliki beberapa sub-materi yang perlu dipelajari secara berurutan.'
    },
    {
      title: 'Pelajari Konten',
      content: 'Setiap materi terdiri dari empat bagian: Capaian Pembelajaran, Konten Materi, Video, dan Referensi. Gunakan tombol "Selanjutnya" untuk berpindah antar bagian.'
    },
    {
      title: 'Virtual Lab',
      content: 'Di Virtual Lab, Anda dapat mensimulasikan pengoperasian berbagai sistem energi terbarukan. Pertama selesaikan tahap perakitan, kemudian jalankan simulasi dengan berbagai parameter.'
    },
    {
      title: 'Evaluasi',
      content: 'Setelah mempelajari semua materi, buka halaman Evaluasi untuk mengakses Google Form penilaian. Jawab semua pertanyaan dengan jujur untuk mengukur pemahaman Anda.'
    },
    {
      title: 'Navigasi Umum',
      content: 'Gunakan tombol "Kembali" untuk kembali ke halaman sebelumnya. Setiap halaman memiliki breadcrumb untuk membantu navigasi.'
    }
  ]

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2">
              <span className="text-accent">Petunjuk</span> Penggunaan
            </h1>
            <p className="text-muted-foreground">Panduan lengkap penggunaan platform ini</p>
          </div>
          <Link href="/menu">
            <Button variant="outline" size="sm">← Kembali</Button>
          </Link>
        </div>

        {/* Guide Items */}
        <div className="space-y-4 mb-8">
          {guides.map((guide, idx) => (
            <div
              key={idx}
              className="bg-card border border-border rounded-lg overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === idx ? -1 : idx)}
                className="w-full px-6 py-4 flex items-center justify-between hover:bg-muted/50 transition-colors"
              >
                <h3 className="text-lg font-semibold text-foreground text-left">{guide.title}</h3>
                {openIndex === idx ? (
                  <ChevronUp className="w-5 h-5 text-primary" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-muted-foreground" />
                )}
              </button>
              {openIndex === idx && (
                <div className="px-6 py-4 bg-muted/30 border-t border-border">
                  <p className="text-muted-foreground leading-relaxed">{guide.content}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="bg-primary/10 border-2 border-primary rounded-xl p-6 mb-8">
          <h2 className="text-xl font-bold text-foreground mb-4">Pertanyaan Umum</h2>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex gap-2">
              <span className="text-primary font-bold">Q:</span>
              <span>Apakah saya perlu menyelesaikan materi secara berurutan?</span>
            </li>
            <li className="flex gap-2 ml-5">
              <span className="text-secondary font-bold">A:</span>
              <span>Tidak, Anda bebas memilih urutan materi mana yang ingin dipelajari terlebih dahulu.</span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary font-bold">Q:</span>
              <span>Dapatkah saya mengulangi Virtual Lab berkali-kali?</span>
            </li>
            <li className="flex gap-2 ml-5">
              <span className="text-secondary font-bold">A:</span>
              <span>Ya, Anda dapat menjalankan simulasi Virtual Lab sebanyak yang Anda inginkan untuk eksperimen yang berbeda.</span>
            </li>
          </ul>
        </div>

        <Link href="/menu">
          <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
            Kembali ke Menu Utama
          </Button>
        </Link>
      </div>
    </div>
  )
}

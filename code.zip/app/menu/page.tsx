'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ChevronRight } from 'lucide-react'

export default function MainMenu() {
  const menuItems = [
    {
      href: '/materi',
      title: 'Materi Pembelajaran',
      description: 'Pelajari berbagai topik energi terbarukan',
      icon: '📚',
      color: 'from-primary to-primary/70'
    },
    {
      href: '/virtual-lab',
      title: 'Virtual Lab',
      description: 'Simulasi interaktif energi terbarukan',
      icon: '🔬',
      color: 'from-secondary to-secondary/70'
    },
    {
      href: '/petunjuk',
      title: 'Petunjuk Penggunaan',
      description: 'Panduan lengkap aplikasi ini',
      icon: '❓',
      color: 'from-accent to-accent/70'
    },
    {
      href: '/profil',
      title: 'Tentang Kami',
      description: 'Tim pengembang dan informasi aplikasi',
      icon: '👥',
      color: 'from-primary to-accent'
    }
  ]

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      {/* Header */}
      <div className="max-w-5xl mx-auto mb-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2">
              Energy <span className="text-primary">Explorer</span>
            </h1>
            <p className="text-muted-foreground">Pilih kategori pembelajaran yang ingin Anda ikuti</p>
          </div>
          <Link href="/">
            <Button variant="outline" size="sm">← Kembali</Button>
          </Link>
        </div>
      </div>

      {/* Menu Grid */}
      <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
        {menuItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div className={`bg-gradient-to-br ${item.color} rounded-2xl p-6 md:p-8 cursor-pointer transform transition-all hover:scale-105 hover:shadow-xl text-white group`}>
              <div className="flex items-start justify-between mb-4">
                <span className="text-4xl md:text-5xl">{item.icon}</span>
                <ChevronRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-2">{item.title}</h2>
              <p className="text-white/90 text-sm md:text-base">{item.description}</p>
            </div>
          </Link>
        ))}
      </div>

      {/* Bottom Navigation Info */}
      <div className="max-w-5xl mx-auto mt-16 p-6 bg-card border border-border rounded-xl">
        <h3 className="font-semibold text-foreground mb-3">💡 Tip</h3>
        <p className="text-sm text-muted-foreground">
          Gunakan navigasi di atas untuk menjelajahi berbagai topik pembelajaran. Setiap topik dilengkapi dengan materi, video, dan referensi untuk pemahaman yang lebih mendalam.
        </p>
      </div>
    </div>
  )
}
